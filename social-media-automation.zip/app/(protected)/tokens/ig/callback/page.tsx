"use client";

export default function InstagramCallbackPage() {
  return (
    <div>
      <h1>Instagram Callback</h1>
    </div>
  );
}
